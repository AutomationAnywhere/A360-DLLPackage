﻿using System.IO;
using System.Net;

namespace BitcoinPrice
{
    public class RestUtils
    {
        public string CallRestGETNoAuth(string URL)
        {
            HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(URL);
            httpWebRequest.ContentType = "text/json";
            httpWebRequest.Method = "GET";
            try
            {
                using (StreamReader streamReader = new StreamReader(httpWebRequest.GetResponse().GetResponseStream()))
                    return streamReader.ReadToEnd();
            }
            catch (WebException ex)
            {
                return "Error:" + ex.Message;
            }
        }
    }
}