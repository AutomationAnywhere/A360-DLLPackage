﻿using RestSharp;
using RestSharp.Serialization.Json;

namespace BitcoinPrice
{
    internal class JsonUtils
    {
        public string GetDataFromJsonResponse(string JsonResp)
        {
            RestResponse restResponse = new RestResponse();
            //((RestResponseBase)restResponse).set_Content(JsonResp);
            restResponse.Content = JsonResp;
            return ((StdJsonResponseForCurrCheck)((JsonSerializer)new JsonDeserializer()).Deserialize<StdJsonResponseForCurrCheck>((IRestResponse)restResponse)).ticker.price;
        }
    }
}

public class StdJsonResponseForCurrCheck
{
    public Ticker ticker { get; set; }

    public int timestamp { get; set; }

    public bool success { get; set; }

    public string error { get; set; }
}

public class Ticker
{
    public string @base { get; set; }

    public string target { get; set; }

    public string price { get; set; }

    public string volume { get; set; }

    public string change { get; set; }
}
