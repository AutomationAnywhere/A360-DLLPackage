﻿namespace BitcoinPrice
{

    public class GetBitcoinPrice
    {

        public string GetPriceOfBitcoin(string Currency)
        {
            string str = "https://api.cryptonator.com/api/ticker/btc-" + Currency;
            RestUtils restUtils = new RestUtils();
            JsonUtils jsonUtils = new JsonUtils();
            string URL = str;
            string noAuth = restUtils.CallRestGETNoAuth(URL);
            return jsonUtils.GetDataFromJsonResponse(noAuth);
        }
    }
}